---
name: Bug Report
about: Report unexpected or inconsistent skill behavior
title: "[Bug] "
labels: bug
---

## What Happened

<!-- Describe what the skill did -->

## What You Expected

<!-- Per SKILL.md, what should have happened instead? Reference the relevant section if possible -->

## Example Query

<!-- The prompt you gave Claude that triggered the issue -->

## Category

- [ ] Cited an excluded source (translation, theologian, or reference work)
- [ ] Mishandled a contested doctrine (didn't flag as contested, or misrepresented the 1689/Westminster positions)
- [ ] Incorrect or inconsistent output format
- [ ] Original language analysis error
- [ ] Other (please describe)

## Additional Context

<!-- Anything else that would help diagnose this -->

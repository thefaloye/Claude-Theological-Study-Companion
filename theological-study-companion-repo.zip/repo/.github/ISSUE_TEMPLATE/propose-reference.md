---
name: Propose a Reference Work or Theologian
about: Suggest an addition to the lexicon/dictionary canon or theologians canon
title: "[Proposal] "
labels: proposal
---

## Type

- [ ] Reference work (lexicon, dictionary, concordance, theological wordbook)
- [ ] Theologian / historical voice

## Name and Dates

<!-- e.g. "Petrus van Mastricht (1630–1706)" or "Theological Dictionary of the New Testament (Kittel, 1964)" -->

## Tradition / Theological Orientation

<!-- Must be evangelical/Reformed-compatible. Note any cautions if the source requires critical engagement (as with Origen, Aquinas, etc.) -->

## Primary Works / Edition Details

<!-- For theologians: list primary works. For reference works: edition, translator, publisher, year -->

## Proposed Placement

<!-- Where in references/reference-works.md or references/theologians-canon.md should this go? Which existing tier or era? -->

## Relevance

<!-- Be specific: what theological loci, tasks, or gaps does this fill that aren't already covered? -->

## Additional Context

<!-- Anything else reviewers should know -->

## Description

<!-- What does this PR change, and why? -->

## Type of Change

- [ ] Correction (fixing an error in existing content)
- [ ] New reference work / theologian addition
- [ ] Refinement to controversy-handling protocol or standing exclusions
- [ ] Output format / usability improvement
- [ ] Documentation update
- [ ] Other (please describe)

## Confessional Check

- [ ] This change is consistent with the 1689 LBCF as primary confessional standard
- [ ] This change does not introduce hyper-charismatic, hyper-cessationist, Open Theist, New Age, or liberal-critical frameworks as legitimate/neutral options
- [ ] This change does not introduce TPT, Mirror Bible, The Message, The Living Bible, or other paraphrases as approved translations
- [ ] If adding a theologian/reference work, I have followed the existing entry format and included a clear relevance note

## Related Issue

<!-- Link any related issue, e.g. "Closes #12" -->

## Additional Notes

<!-- Anything else reviewers should know -->
